<?php

    session_start();
    $host   = 'localhost';
    $user   = 'root';
    $password = '';
    $database = 'skripsi';

    $link = mysqli_connect($host, $user, $password);
    $conn  = mysqli_select_db($link, $database) or die(mysqli_error($link));

?>