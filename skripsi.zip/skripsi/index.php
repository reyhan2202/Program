<?php
        include "conn.php";
        include "top.php";
?>
        <!-- Page content-->
        <div class="container">
            <div class="mt-5">
                <h1>Test</h1>
                <?php
                    $q="SELECT * FROM user";
                    $res=mysqli_query($link,$q);

                    while ($row=mysqli_fetch_assoc($res))
                    {
                        print_r($row);
                        echo "<br/>";
                    }
                ?>
                <div class="content">
                    <div class="images">
                        <img id="image" src="admin/images/noimage.png">
                        <div class="description">
                            <h2>Harga</h2>
                            <p>Deskripsi</p>
                        </div>
                    </div>
                    <div class="images">
                        <img id="image" src="admin/images/noimage.png">
                        <div class="description">
                            <h2>Harga</h2>
                            <p>Deskripsi</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
        include "bottom.php";
?>