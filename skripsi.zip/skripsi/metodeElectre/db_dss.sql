-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2022 at 08:10 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_dss`
--

-- --------------------------------------------------------

--
-- Table structure for table `electre_alternatives`
--

CREATE TABLE `electre_alternatives` (
  `id_alternative` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `electre_alternatives`
--

INSERT INTO `electre_alternatives` (`id_alternative`, `name`) VALUES
(1, 'Pulomas'),
(2, 'Pulo Gebang'),
(3, 'Ancol'),
(4, 'Cibitung'),
(5, 'Grogol'),
(6, 'Cikarang'),
(7, 'Cengkareng');

-- --------------------------------------------------------

--
-- Table structure for table `electre_criterias`
--

CREATE TABLE `electre_criterias` (
  `id_criteria` tinyint(3) UNSIGNED NOT NULL,
  `criteria` varchar(100) NOT NULL,
  `weight` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `electre_criterias`
--

INSERT INTO `electre_criterias` (`id_criteria`, `criteria`, `weight`) VALUES
(1, 'jarak dengan pusat niaga terdekat(km)', 6),
(2, 'kepadatan penduduk disekitar lokasi (orang/km2)', 2),
(3, 'jarak dari pabrik(km)', 3),
(4, 'jarak dengan gudang yang sudah ada (km)', 3),
(5, 'harga tanah untuk lokasi (x1000 Rp/m2)', 3);

-- --------------------------------------------------------

--
-- Table structure for table `electre_evaluations`
--

CREATE TABLE `electre_evaluations` (
  `id_alternative` smallint(5) UNSIGNED NOT NULL,
  `id_criteria` tinyint(3) UNSIGNED NOT NULL,
  `value` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `electre_evaluations`
--

INSERT INTO `electre_evaluations` (`id_alternative`, `id_criteria`, `value`) VALUES
(1, 1, 2),
(1, 2, 3),
(1, 3, 4),
(1, 4, 2),
(1, 5, 2),
(2, 1, 5),
(2, 2, 4),
(2, 3, 1),
(2, 4, 2),
(2, 5, 1),
(3, 1, 1),
(3, 2, 3),
(3, 3, 2),
(3, 4, 3),
(3, 5, 4),
(4, 1, 5),
(4, 2, 3),
(4, 3, 1),
(4, 4, 1),
(4, 5, 5),
(5, 1, 1),
(5, 2, 2),
(5, 3, 3),
(5, 4, 5),
(5, 5, 3),
(6, 1, 2),
(6, 2, 2),
(6, 3, 5),
(6, 4, 3),
(6, 5, 1),
(7, 1, 5),
(7, 2, 3),
(7, 3, 4),
(7, 4, 2),
(7, 5, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `electre_alternatives`
--
ALTER TABLE `electre_alternatives`
  ADD PRIMARY KEY (`id_alternative`);

--
-- Indexes for table `electre_criterias`
--
ALTER TABLE `electre_criterias`
  ADD PRIMARY KEY (`id_criteria`);

--
-- Indexes for table `electre_evaluations`
--
ALTER TABLE `electre_evaluations`
  ADD PRIMARY KEY (`id_alternative`,`id_criteria`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `electre_alternatives`
--
ALTER TABLE `electre_alternatives`
  MODIFY `id_alternative` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
