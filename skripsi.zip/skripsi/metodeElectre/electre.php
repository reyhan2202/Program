<?php
//-- Koneksi ke Database Server
//-- database configurations
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$dbname='db_dss';
//-- database connections
$db=new mysqli($dbhost,$dbuser,$dbpass,$dbname);
//-- halt and show error message if connection fail
if ($db->connect_error) {
    die('Connect Error ('.$db->connect_errno.')'.$db->connect_error);
}
?>

<?php
//-- Membentuk Perbandingan Berpasangan (X)
   //-- query untuk mengambil data jumlah kriteria 'n'
  $sql="SELECT COUNT(*)
        FROM electre_criterias";
  $result=$db->query($sql);
  $row=$result->fetch_row();
  //--- inisialisasi jumlah kriteria 'n'
  $n=$row[0];
  //-- query untuk mengambil data Perbandingan Berpasangan X
  $sql="SELECT *
        FROM electre_evaluations
        ORDER BY id_alternative,id_criteria";
  $result=$db->query($sql);
  $X=array();
  $alternative='';
  //--- inisialisasi jumlah alternative 'm'
  $m=0;
  while($row=$result->fetch_row()){
    
    if($row[0]!=$alternative){
      $X[$row[0]]=array();
      $alternative=$row[0];
      ++$m;
    }
    $X[$row[0]][$row[1]]=$row[2];
  }
echo "Membentuk Perbandingan Berpasangan (X) <br>";
    print_r($X);
    echo "<br><br>";
?>

<?php
//-- Membuat Matriks Perbandingan Berpasangan Ternormalisasi (R)
//-- menentukan nilai rata-rata kuadrat per-kriteria
$x_rata=array();
foreach($X as $i=>$x){
  foreach($x as $j=>$value){
    $x_rata[$j]=(isset($x_rata[$j])?$x_rata[$j]:0)+pow($value,2);
  }
}
for($j=1;$j<=$n;$j++){
  $x_rata[$j]=sqrt($x_rata[$j]);
}
//-- menormalisasi matriks X menjadi matriks R
$R=array();
$alternative='';
foreach($X as $i=>$x){
  if($alternative!=$i){
    $alternative=$i;
    $R[$i]=array();
  }
  foreach($x as $j=>$value){
    $R[$i][$j]=$value/$x_rata[$j];
  }
}
echo "Matriks Perbandingan Berpasangan Ternormalisasi (R) <br>";
print_r($R);
echo "<br><br>";
?>

<?php
//-- Menentukan Bobot tiap-tiap Kriteria (W)
  //-- query untuk mengambil data nilai bobot criteria
  $sql="SELECT id_criteria, weight
        FROM electre_criterias
        ORDER BY id_criteria";
  $result=$db->query($sql);
  $criteria=array();
  //print_r($result);
  while($row=$result->fetch_row()) 
    //print_r($row);
    $criteria[$row[0]]=$row[1];
echo "Menentukan Bobot tiap-tiap Kriteria (W) <br>";
  print_r($criteria);
echo "<br><br>";
?>

<?php
//-- Membentuk Matrik Preferensi (V)
//-- inisialisasi matrik preferensi V dan himpunan bobot kriteria w
$V=$w=array();
//-- memasukkan data bobot ke dalam $w
foreach($criteria as $j=>$weight)
  $w[$j]=$weight;
$alternative='';
//-- menghitung nilai Preferensi V
foreach($R as $i=>$r){
  if($alternative!=$i){
    $alternative=$i;
    $V[$i]=array();
  }
  foreach($r as $j=>$value){
    $V[$i][$j]=$w[$j]*$value;
  }
}
echo "Membentuk Matrik Preferensi (V) <br>";
print_r($V);
echo "<br><br>";
?>

<?php
//-- Menentukan Concordance Index (Ckl)
  /* mencari himpunan concordance index
     $n = jumlah kriteria
     $m = jumlah alternatif
     $V = matrik preferensi
     $c = himpunan concordance index
  */
  $c=array();
  $c_index='';
  for($k=1;$k<=$m;$k++){
    if($c_index!=$k){
      $c_index=$k;
      $c[$k]=array();
    }
    for($l=1;$l<=$m;$l++){
      if($k!=$l){
        for($j=1;$j<=$n;$j++){
          if(!isset($c[$k][$l]))$c[$k][$l]=array();
          if($V[$k][$j]>=$V[$l][$j]){
            array_push($c[$k][$l],$j);
          }
        }
      }
    }
  }
echo "Menentukan Concordance Index <br>";
  print_r($c);
echo "<br><br>";
?>

<?php
//-- Menentukan Discordance Index (Dkl)

  /* mencari himpunan discordance index
     $n = jumlah kriteria
     $m = jumlah alternatif
     $V = matrik preferensi
     $c = himpunan discordance index
  */
  $d=array();
  $d_index='';
  for($k=1;$k<=$m;$k++){
    if($d_index!=$k){
      $d_index=$k;
      $d[$k]=array();
    }
    for($l=1;$l<=$m;$l++){
      if($k!=$l){
        for($j=1;$j<=$n;$j++){
          if(!isset($d[$k][$l]))$d[$k][$l]=array();
          if($V[$k][$j]<$V[$l][$j]){
            array_push($d[$k][$l],$j);
          }
        }
      }
    }
  }
echo "Menentukan Discordance Index <br>";
print_r($d);
echo "<br><br>";
?>

<?php
//-- Membentuk Matriks Concordance (C)
$C=array();
$c_index='';
for($k=1;$k<=$m;$k++){
  if($c_index!=$k){
    $c_index=$k;
    $C[$k]=array();
  }
  for($l=1;$l<=$m;$l++){
    if($k!=$l && count($c[$k][$l])){
      $f=0;
      foreach($c[$k][$l] as $j){
        $C[$k][$l]=(isset($C[$k][$l])?$C[$k][$l]:0)+$w[$j];
      }
    }
  }
}
echo "Matrix Concordance <br>";
print_r($C);
echo "<br><br>";
?>

<?php
//-- Membentuk Matriks Discordance (D)
$D=array();
$d_index='';
for($k=1;$k<=$m;$k++){
  if($d_index!=$k){
    $d_index=$k;
    $D[$k]=array();
  }
  for($l=1;$l<=$m;$l++){
    if($k!=$l){
      $max_d=0;
      $max_j=0;
      if(count($d[$k][$l])){
        $mx=array();
        foreach($d[$k][$l] as $j){
          if($max_d<abs($V[$k][$j]-$V[$l][$j]))
            $max_d=abs($V[$k][$j]-$V[$l][$j]);
        }
      }
      $mx=array();
      for($j=1;$j<=$n;$j++){
        if($max_j<abs($V[$k][$j]-$V[$l][$j]))
          $max_j=abs($V[$k][$j]-$V[$l][$j]);
      }
      $D[$k][$l]=$max_d/$max_j;
    }
  }
}
echo "Matrix Discordance <br>";
print_r($D);
echo "<br><br>";
?>

<?php
//-- Menghitung Threshold c
$sigma_c=0;
foreach($C as $k=>$cl){
  foreach($cl as $l=>$value){
    $sigma_c+=$value;
  }
}
$threshold_c=$sigma_c/($m*($m-1));
echo "Threshold concordance <br>";
print_r($threshold_c);
echo "<br><br>";
?>

<?php
//-- Menghitung Threshold d
$sigma_d=0;
foreach($D as $k=>$dl){
  foreach($dl as $l=>$value){
    $sigma_d+=$value;
  }
}
$threshold_d=$sigma_d/($m*($m-1));
echo "Threshold discordance <br>";
print_r($threshold_d);
echo "<br><br>";
?>

<?php
//-- Membentuk Matrik Concordance Dominan(F)
  $F=array();
  foreach($C as $k=>$cl){
    $F[$k]=array();
    foreach($cl as $l=>$value){
      $F[$k][$l]=($value>=$threshold_c?1:0);
    }
  }
echo "Matrix Concordance Dominan <br>";
  print_r($F);
echo "<br><br>";
?>

<?php
//-- Membentuk Matrik Discordance Dominan(G)
  $G=array();
  foreach($D as $k=>$dl){
    $G[$k]=array();
    foreach($dl as $l=>$value){
      $G[$k][$l]=($value>=$threshold_d?1:0);
    }
  }
echo "Matrix Discordance Dominan <br>";
print_r($G);
echo "<br><br>";
?>

<?php
//-- Membentuk Matrik Agregasi Dominan(E)
  $E=array();
  foreach($F as $k=>$sl){
    $E[$k]=array();
    foreach($sl as $l=>$value){
      $E[$k][$l]=$F[$k][$l]*$G[$k][$l];
    }
  }
echo "Matrix Agregasi Dominan <br>";
  print_r($E);
echo "<br><br>";
?>