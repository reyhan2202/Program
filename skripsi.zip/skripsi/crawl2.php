<?php
	include "simple_html_dom.php";
	include "conn.php";
	function get_web_page( $url )
    {
        $user_agent='Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';

        $options = array(

            CURLOPT_CUSTOMREQUEST  =>"GET",        //set request type post or get
            CURLOPT_POST           =>false,        //set to GET
            CURLOPT_USERAGENT      => $user_agent, //set user agent
            CURLOPT_COOKIEFILE     =>"cookie.txt", //set cookie file
            CURLOPT_COOKIEJAR      =>"cookie.txt", //set cookie jar
            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
            CURLOPT_TIMEOUT        => 120,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        );

        $ch      = curl_init( $url );
        curl_setopt_array( $ch, $options );
        $content = curl_exec( $ch );
        $err     = curl_errno( $ch );
        $errmsg  = curl_error( $ch );
        $header  = curl_getinfo( $ch );
        curl_close( $ch );

        $header['errno']   = $err;
        $header['errmsg']  = $errmsg;
        $header['content'] = $content;
        return $header;
    }


    //rumah.com ada bot protection

    $temp=file_get_html("https://rumah.trovit.co.id/index.php/cod.search_adwords_homes/type.1/what_d.rumah%20surabaya/tracking.%7B%22acc%22%3A5758%2C%22c%22%3A12426809907%2C%22a%22%3A119780516073%2C%22d%22%3A%22c%22%7D/ppc_landing_type.3/origin.20/device.%7Bdevice%7D/tg.20-3-%7B%22acc%22%3A5758%2C%22c%22%3A12426809907%2C%22a%22%3A119780516073%2C%22d%22%3A%22c%22%7D?gclid=CjwKCAjwkYGVBhArEiwA4sZLuNOONKVxBuDu4TfpZMrm8zVko8XW4qictn2GlrW6JLS6dCrQ2POoARoCRzoQAvD_BwE");


   	//file_put_contents("test.txt",$hsl["content"]);

    //$temp=str_get_html($hsl["content"]);

    if ($temp==null)
    {
    	echo "null";
    }

   foreach ($temp->find('div.snippet-wrapper') as $e) {
        echo $e->innertext;
        echo "<br/>";
   }
?>