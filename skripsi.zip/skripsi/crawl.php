<?php
	include "simple_html_dom.php";
	include "conn.php";
	function get_web_page( $url )
    {
        $user_agent='Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';

        $options = array(

            CURLOPT_CUSTOMREQUEST  =>"GET",        //set request type post or get
            CURLOPT_POST           =>false,        //set to GET
            CURLOPT_USERAGENT      => $user_agent, //set user agent
            CURLOPT_COOKIEFILE     =>"cookie.txt", //set cookie file
            CURLOPT_COOKIEJAR      =>"cookie.txt", //set cookie jar
            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
            CURLOPT_TIMEOUT        => 120,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        );

        $ch      = curl_init( $url );
        curl_setopt_array( $ch, $options );
        $content = curl_exec( $ch );
        $err     = curl_errno( $ch );
        $errmsg  = curl_error( $ch );
        $header  = curl_getinfo( $ch );
        curl_close( $ch );

        $header['errno']   = $err;
        $header['errmsg']  = $errmsg;
        $header['content'] = $content;
        return $header;
    }


    //rumah.com ada bot protection

    $temp=file_get_html("https://www.rumah123.com/jual/surabaya/rumah");


   	//file_put_contents("test.txt",$hsl["content"]);

    //$temp=str_get_html($hsl["content"]);

    if ($temp==null)
    {
    	echo "null";
    }

    foreach ($temp->find('div.ui-organisms-card-r123-featured') as $e) {
	  //echo $e->innertext;
	  //echo "<br/>";

	  $h2=$e->find("h2",0);
	  $img=$e->find("img",0);
      $kamarTidur=$e->find("span.attribute-text",0);
      $kamarMandi=$e->find("span.attribute-text",1);
      $garasi=$e->find("span.attribute-text",2);
      $luasTanah=$e->find("span.attribute-value",0);
	  $luasBangunan=$e->find("span.attribute-value",1);
      $alamat=$e->find("p.ui-organisms-card-r123-featured__middle-section__address",0);
	  $harga=$e->find("strong",0);
      $cicilan=$e->find("em",0);
	  $url=$e->find("a",0);

	  echo "Judul ".$h2->innertext."<br/>";
	  echo "Gambar ".$img->src."<br/>";
      echo "Kamar Tidur ".$kamarTidur->innertext."<br/>";
      echo "Kamar Mandi ".$kamarMandi->innertext."<br/>";
      if (!isset($garasi)) {
          echo "Tidak Ada Garasi<br/>";
      }else{
        echo "Garasi ".$garasi->innertext."<br/>";
      }
      echo "Luas Bangunan ".$luasBangunan->innertext."<br/>";
	  echo "Luas Tanah ".$luasTanah->innertext."<br/>";
	  echo "Alamat ".$alamat->innertext."<br/>";
      echo "Harga ".$harga->innertext."<br/>";
      echo $cicilan->innertext."<br/>";
	  echo "URL ".$url->href."<br/>";
	  echo "<br/>";

	  /*
	  $desc=mysqli_real_escape_string($link,$h2->innertext);
      $q="INSERT INTO produk (deskripsi) VALUES ('$desc')";
      mysqli_query($link,$q);

      $idP=mysqli_insert_id($link);


      $gbr=mysqli_real_escape_string($link,$img->src);
      $q="INSERT INTO gambar (namaGambar,Produk_idProduk) VALUES ('$gbr','$idP') ";
      mysqli_query($link,$q);
      */


	  //$first[] = $e->next_sibling();

	}

?>