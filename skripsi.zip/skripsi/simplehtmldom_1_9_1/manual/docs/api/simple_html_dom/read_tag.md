# read_tag (protected)

```php
read_tag () : bool
```

Reads a single tag starting at the current parsing position in the document. The tag is automatically added to the DOM.

Returns true if a tag was found.