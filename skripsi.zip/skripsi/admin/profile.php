<?php 
 
include '../conn.php';
include 'head.php';
 
error_reporting(0);
 
session_start();
 
if (!isset($_SESSION['username'])) {
     header('Location: ../index.php');
 } 
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    //header("Location: ../index.php");
    $sql = "SELECT * FROM user WHERE username='$username'";
    $result = mysqli_query($link, $sql);
    if($result->num_rows > 0){
        $row=$result->fetch_row();
        $id = $row[0];
        $username = $row[1];
        $email = $row[2];
        $password = $row[3];
        $level = $row[4];
    }
}
if ($_POST['submit']=="update") {
    echo $_POST['submit'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $level = $_POST['level'];

        $sql = "UPDATE user SET username = '$username', email = '$email', password = '$password', level = '$level' WHERE user.id = '$id'";
        $result = mysqli_query($link, $sql);
        if ($result) {
            echo "<script>alert('Selamat, update profile berhasil!')</script>";
            $_SESSION['username']= $username;
        } else {
            echo "<script>alert('Woops! Terjadi kesalahan.')</script>";
        }
}elseif ($_POST['submit']=='delete') {
    $sql = "DELETE FROM user WHERE user.id = '$id'";
    $result = mysqli_query($link, $sql);
    if ($result) {
        echo "<script>alert('akun berhasil dihapus')</script>";
        session_destroy();
        header("Location: ../index.php");
    } else {
        echo "<script>alert('Woops! Terjadi kesalahan.')</script>";
    }
}elseif ($_POST['submit']=='cancel') {
    header('Location: ../index.php');
}
 
?>
 

    <div class="container">
        <form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Profile</p>
            <div class="input-group">
                <input type="text" placeholder="Username" name="username" value="<?php echo $username; ?>" required>
            </div>
            <div class="input-group">
                <input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" id="password" name="password" value="<?php echo $password; ?>" required>
            </div>
                <input type="checkbox" onclick="myFunction()" >Show Password
            <div class="input-group">
                <select name="level" value="<?php echo $level; ?>" required>
                    <?php 
                    if ($level=="1") {
                        ?><option value='1' selected>Admin</option><?php
                    }
                     ?>
                    <option value="2"<?php if ($level=="2")echo'selected';?>>Agen Properti</option>
                    <option value="3"<?php if ($level=="3")echo'selected';?>>Pembeli</option>
                </select>
            </div>
            <div class="input-group">
                <button name="submit" class="btn" value="update">Update</button>
            </div>
            <div class="input-group">
                <button name="submit" class="btn" value="delete">Delete</button>
            </div>
            <div class="input-group">
                <button name="submit" class="btn" value="cancel">Cancel</button>
            </div>
        </form>
    </div>
