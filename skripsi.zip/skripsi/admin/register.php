<?php 
 
include '../conn.php';
include 'head.php';
 
error_reporting(0);
 
session_start();
 
if (isset($_SESSION['username'])) {
    header("Location: ../index.php");
}
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $level = $_POST['level'];
 
    if ($password == $cpassword) {
        $sql = "SELECT * FROM user WHERE email='$email'";
        $result = mysqli_query($link, $sql);
        if (!$result->num_rows > 0) {
            $sql = "INSERT INTO user (username, email, password, level)
                    VALUES ('$username', '$email', '$password', '$level')";
            $result = mysqli_query($link, $sql);
            if ($result) {
                echo "<script>alert('Selamat, registrasi berhasil!')</script>";
                $username = "";
                $email = "";
                $_POST['password'] = "";
                $_POST['cpassword'] = "";
                $_POST['level'] = "";
                header('Location: login.php');
            } else {
                echo "<script>alert('Woops! Terjadi kesalahan.')</script>";
            }
        } else {
            echo "<script>alert('Woops! Email Sudah Terdaftar.')</script>";
        }
         
    } else {
        echo "<script>alert('Password Tidak Sesuai')</script>";
    }
}
 
 
?>
 

    <div class="container">
        <form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Register</p>
            <div class="input-group">
                <input type="text" placeholder="Username" name="username" value="<?php echo $username; ?>" required>
            </div>
            <div class="input-group">
                <input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" id="password" name="password" value="<?php echo $_POST['password']; ?>" required>
            </div>
            <input type="checkbox" onclick="myFunction()" >Show Password
            <div class="input-group">
                <input type="password" placeholder="Confirm Password" id='cpassword' name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>
            </div>
            <input type="checkbox" onclick="myCPass()" >Show Password
            <div class="input-group">
                <select name="level" value="<?php echo $_POST['level']; ?>" required>
                 <!--   <option value="2"<?php if ($_POST['level']=="2")echo'selected';?>>Agen Properti</option>-->
                    <option value="3"<?php if ($_POST['level']=="3")echo'selected';?>>Pembeli</option>
                </select>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Register</button>
            </div>
            <p class="login-register-text">Anda sudah punya akun? <a href="login.php">Login </a></p>
        </form>
    </div>